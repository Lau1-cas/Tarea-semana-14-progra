package gt.edu.umg.demop2bprimero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demop2bprimeroApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demop2bprimeroApplication.class, args);
	}

}
